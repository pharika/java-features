
public class example {
	public static void main(String[] args) {
		int a=100;  
        Integer a2=new Integer(a);//Boxing  
  
        Integer a3=10;//Boxing  
          
        System.out.println(a2+" "+a3);  
	}
}
