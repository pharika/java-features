
public class examp2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Integer i=new Integer(100);  
	        int a=i;  
	          
	        System.out.println(a);  
	}

}
