
public class example {
	public static void main(String[] args) {  
        // Underscore in integral literal  
        int a = 10_00000;  
        System.out.println("a = "+a);
        int c = 0B10_10;  
        System.out.println("c = "+c);  
        // Underscore in hexadecimal literal  
        int d = 0x1_1;  
        System.out.println("d = "+d);  
        // Underscore in octal literal  
        int e = 01_1;  
        System.out.println("e = "+e);  

}
}
