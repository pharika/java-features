interface Sayable{  
	    void say();  
	}  
	public class examplee { 
	    public static void saySomething(){  
	        System.out.println("Hello, this is java.");  
	    }  
	    public static void main(String[] args) {  
	        // Referring static method  
	        Sayable sayable = examplee::saySomething;  
	        // Calling interface method  
	        sayable.say();  

}
}