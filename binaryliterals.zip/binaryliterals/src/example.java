
public class example {
	    public static void main(String[] args) {  
	        // Binary literal in byte type  
	        byte b1 = 0b101;    // Using b0, The b can be lower or upper case  
	        byte b2 = 0B101;    // Using B0  
	        System.out.println("----------Binary Literal in Byte----------------");  
	        System.out.println("b1 = "+b1);  
	        System.out.println("b2 = "+b2);  
	    }
}
	          
	          
	    

