public class example {
		static void enter(String... values){  
			  System.out.println("enter method invoked ");  
			  for(String s:values){  
			   System.out.println(s);  
			  }  
			 }  
			  
			 public static void main(String args[]){  
			  
			 enter();
			 enter("hello"); 
			 enter("my","name","is","varargs");
	}
	

}
