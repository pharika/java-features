import static java.lang.System.*;    
public class exam {
	public static void main(String args[]){  
	     
		   out.println("hello");
		   out.println("hello");
	}
}
