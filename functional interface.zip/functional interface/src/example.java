interface sayble{  
    void say(String msg);  
}  


public class example{
	public void say(String msg){  
        System.out.println(msg);  
    }  
    public static void main(String[] args) {  
        example a1 = new example();  
        a1.say("Hello");  
	
	
	
}
}
