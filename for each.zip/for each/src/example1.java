public class example1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int arr[]={1,2,3,4};  
		   //traversing the array with for-each loop  
		   for(int i:arr){  
		     System.out.println(i);  
		   }  
		 }   

	}


