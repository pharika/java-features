
public class example {

}
